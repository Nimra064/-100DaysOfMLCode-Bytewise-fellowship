# Corona-Virus-2023-Data-Analysis-
The WHO coronavirus (COVID-19) dashboard presents official daily counts of COVID-19 cases, deaths and vaccine utilisation reported by countries, territories and areas. Through this dashboard, we aim to provide a frequently updated data visualization, data dissemination and data exploration resource
