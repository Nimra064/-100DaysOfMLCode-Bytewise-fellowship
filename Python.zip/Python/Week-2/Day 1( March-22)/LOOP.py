

# Display the Message 10 time'How are you'


# for i in range(0,10):
#     print('How are You')


# Display the Message 1 time'How are you' after display Loop Terminate

successful=True
for i in range(0,10):
    print('How are You')
    if successful:
        break
