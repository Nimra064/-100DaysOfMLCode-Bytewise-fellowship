

def save_fun(num):
    if num%2==0:
        print('Python Developer')
    else:
        print('Not Accessiable')


print(save_fun(3))