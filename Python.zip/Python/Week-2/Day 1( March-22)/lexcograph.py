

for x in range(2):
    for y in range(3):
        for z in range(3):
            print(f'{x},{y},{z}')


# Display each character of String# Display the Message 10 time'How are you'

for i in 'NIMRA':
    print(i)
