# Display the 50 Even Number 

n=50

for i in range (0,n):
    if(i%2==0):
        print('Even Number =' , i)
    i=i+1
