import pandas_function as pf
import numpy as np

arr=np.array([1,2,3,4,5,6])
arr=arr.reshape(3,2)
x=pf.check_shape_array(arr)
print(x)

