# Supervised-Machine-Learning-Course-Solve-Solution-on-Coursera-2023
In the first course of the Machine Learning Specialization, you will:  • Build machine learning models in Python using popular machine learning libraries NumPy and scikit-learn. • Build and train supervised machine learning models for prediction and binary classification tasks, including linear regression and logistic regression
